import{a as t}from"../chunks/entry.Dii1xf4m.js";export{t as start};
