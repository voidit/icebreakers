import{a as t}from"../chunks/entry.Dp5hZ2Xi.js";export{t as start};
