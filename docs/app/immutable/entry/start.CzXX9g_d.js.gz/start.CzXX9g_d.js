import{a as t}from"../chunks/entry.DelKLhEm.js";export{t as start};
