import{a as t}from"../chunks/entry.D29V-RB1.js";export{t as start};
