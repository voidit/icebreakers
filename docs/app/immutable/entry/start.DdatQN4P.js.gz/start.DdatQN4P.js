import{a as t}from"../chunks/entry.CFQ6W_RK.js";export{t as start};
