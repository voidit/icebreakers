import{a as t}from"../chunks/entry.a3w3UMAl.js";export{t as start};
